from django.db import models

# Create your models here.
class Product(models.Model):
    name = models.CharField(max_length=200,blank=False)
    weight = models.FloatField(blank=False)
    price = models.DecimalField(max_digits=4, decimal_places=2)
    created_at = models.CharField(max_length=200, blank=False)
    updated_at = models.CharField(max_length=100, blank=False)


    def __str__(self):
        return self.name

    class Meta:
        db_table = 'PRODUCT'