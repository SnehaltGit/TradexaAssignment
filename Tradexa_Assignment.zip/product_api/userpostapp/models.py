from django.db import models

# Create your models here.
class User(models.Model):
    first_name = models.CharField(max_length=200, null=False,blank=False)
    last_name = models.CharField(max_length=100, null=False, blank=False)
    email = models.EmailField()
    password = models.CharField(max_length=50)
    username = models.CharField(max_length=35)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'USER'


class Post(models.Model):
    text = models.CharField(max_length=35)
    created_at = models.CharField(max_length=200, null=False,blank=False)
    updated_at = models.CharField(max_length=100, null=False, blank=False)
    user = models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'POST'

