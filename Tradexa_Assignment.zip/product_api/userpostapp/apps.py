from django.apps import AppConfig


class UserpostappConfig(AppConfig):
    name = 'userpostapp'
